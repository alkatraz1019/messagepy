import requests
import json
import hashlib
import os
import time
import sys

# ==============================================================================
# ⚠️ CONFIGURAZIONE NECESSARIA ⚠️ 
# SOSTITUISCI CON I TUOI DATI REALI PER POTER ESEGUIRE IL TEST
# ==============================================================================
GITHUB_USER = "alkatraz1019"       # Es. "google"
GITHUB_REPO = "Auto_Aggiornamento"    # Es. "python-docs-samples"
GITHUB_BRANCH = "main"             # Il branch dove risiede metadata.json

# Versione attuale del tuo programma in esecuzione
CURRENT_VERSION = "1.0.0" 

# URL statico per i metadati (punta al file nel branch principale)
METADATA_URL = f"https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/{GITHUB_BRANCH}/metadata.json"

# --- Variabili di Stato Interne ---
DOWNLOAD_INFO = {} 
DOWNLOAD_DIR = "./temp_update_test"

# ==============================================================================
# FUNZIONI CORE PER LA SICUREZZA E L'EFFICIENZA
# ==============================================================================

def calculate_sha256(filepath):
    """Calcola l'hash SHA256 di un file e misura il tempo impiegato."""
    start_time = time.time()
    sha256_hash = hashlib.sha256()
    
    try:
        with open(filepath, "rb") as f:
            # Buffer di lettura efficiente per file grandi
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
                
        end_time = time.time()
        duration = end_time - start_time
        
        return sha256_hash.hexdigest(), duration
    except IOError:
        return None, 0

def check_for_update_efficiency(current_version):
    """Controlla la versione su GitHub e cronometra la latenza."""
    global DOWNLOAD_INFO
    
    start_time = time.time()
    
    try:
        print(f"\n--- TEST 1: Verifica Efficienza Connessione ---")
        print(f"Versione attuale: {current_version}")
        
        # Misura il tempo di connessione e richiesta (latenza)
        response = requests.get(METADATA_URL, timeout=10)
        response.raise_for_status() # Lancia un errore per 4xx/5xx status
        
        metadata = response.json()
        
        latest_version = metadata.get("latest_version", "0.0.0")
        
        # Salva le info necessarie per il download (inclusa la sicurezza)
        DOWNLOAD_INFO = {
            "version": latest_version,
            "filename": metadata.get("filename"),
            "checksum": metadata.get("sha256_checksum")
        }

        # Confronto delle versioni (parsing per confronto numerico)
        current_v_parts = tuple(map(int, current_version.split('.')))
        latest_v_parts = tuple(map(int, latest_version.split('.')))
        
        is_update_available = latest_v_parts > current_v_parts
        
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"   Versione Server: {latest_version}")
        print(f"   ⏱️ Tempo totale di verifica: {duration:.4f} secondi")

        return is_update_available

    except requests.exceptions.RequestException as e:
        print(f"   Errore di rete/connessione: {e}")
        end_time = time.time()
        print(f"   ⏱️ Tentativo terminato in: {time.time() - start_time:.4f} secondi")
        return False
    except json.JSONDecodeError:
        print("   Errore: Il file di metadati non è un JSON valido.")
        return False

def download_and_verify_efficiency():
    """Scarica il file di aggiornamento, misura il tempo di download e verifica l'hash."""
    
    if not DOWNLOAD_INFO.get("filename") or not DOWNLOAD_INFO.get("checksum"):
        print("Errore: Informazioni di download (nome file o checksum) mancanti.")
        return
        
    filename = DOWNLOAD_INFO["filename"]
    expected_checksum = DOWNLOAD_INFO["checksum"]
    
    # Costruisce l'URL di download diretto dell'Asset di Release
    # Assumiamo che il tag di release sia "v" + versione (es. v2.0.0)
    DOWNLOAD_URL = (
        f"https://github.com/{GITHUB_USER}/{GITHUB_REPO}/releases/download/"
        f"v{DOWNLOAD_INFO['version']}/{filename}"
    )
    local_path = os.path.join(DOWNLOAD_DIR, filename)
    
    print(f"\n--- TEST 2: Efficienza Download & Checksum ---")
    
    try:
        # FASE 1: DOWNLOAD E CRONOMETRAGGIO
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        print(f"   Inizio download da: {DOWNLOAD_URL}")
        
        start_download_time = time.time()
        
        response = requests.get(DOWNLOAD_URL, stream=True, timeout=60)
        response.raise_for_status() 
        
        downloaded_bytes = 0
        with open(local_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded_bytes += len(chunk)
        
        end_download_time = time.time()
        download_duration = end_download_time - start_download_time
        
        speed_mbps = (downloaded_bytes / download_duration) / (1024 * 1024) if download_duration > 0 else 0
        
        print(f"   Dimensione file: {downloaded_bytes / (1024 * 1024):.2f} MB")
        print(f"   ⏱️ Tempo Download: {download_duration:.4f} secondi")
        print(f"   Velocità media: {speed_mbps:.2f} MB/s")

        # FASE 2: VERIFICA HASH E CRONOMETRAGGIO
        print("\n   Inizio verifica integrità (Checksum)...")
        actual_checksum, hash_duration = calculate_sha256(local_path)
        
        total_time = download_duration + hash_duration
        
        print(f"   ⏱️ Tempo calcolo Checksum: {hash_duration:.4f} secondi")
        
        if actual_checksum and actual_checksum.lower() == expected_checksum.lower():
            print(f"   ✅ Checksum riuscito. Tempo totale operazione: {total_time:.4f} secondi")
        else:
            print("   ❌ ERRORE DI SICUREZZA: Checksum non corrispondente!")
            print(f"   Aspettato: {expected_checksum}")
            print(f"   Trovato:   {actual_checksum}")
            
    except requests.exceptions.RequestException as e:
        print(f"   Errore durante il download da GitHub: {e}")
    except Exception as e:
        print(f"   Errore generico: {e}")
    finally:
        # Pulizia
        if os.path.exists(local_path):
            os.remove(local_path)
        if os.path.exists(DOWNLOAD_DIR) and not os.listdir(DOWNLOAD_DIR):
            os.rmdir(DOWNLOAD_DIR)
        print("   Pulizia file temporanei completata.")

# ==============================================================================
# ESECUZIONE PRINCIPALE
# ==============================================================================
if __name__ == "__main__":
    
    print("Inizio test di auto-aggiornamento.")
    
    # Chiamata alla funzione di verifica (Test 1)
    if check_for_update_efficiency(CURRENT_VERSION):
        # Chiamata alla funzione di download e verifica (Test 2)
        download_and_verify_efficiency()
    else:
        print("\nNessun aggiornamento necessario. Test di verifica terminato.")

    print("\nTest di efficienza completato.")